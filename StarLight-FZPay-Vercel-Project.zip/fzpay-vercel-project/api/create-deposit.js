const crypto=require("node:crypto");
const {getDb,required,sign,jsonBody,minor}=require("./_lib/fzpay");
module.exports=async function(req,res){
 res.setHeader("Cache-Control","no-store");
 if(req.method!=="POST")return res.status(405).json({ok:false,message:"POST required"});
 let orderNo="";
 try{
  const b=jsonBody(req),phone=String(b.phone||"").trim(),method=String(b.method||"").toUpperCase(),amountText=String(b.amount||"").trim();
  if(!/^[0-9]{6,20}$/.test(phone))return res.status(400).json({ok:false,message:"Invalid account phone"});
  let amountMinor;try{amountMinor=minor(amountText);}catch{return res.status(400).json({ok:false,message:"Invalid deposit amount"});}
  if(amountMinor<100||amountMinor>100000000)return res.status(400).json({ok:false,message:"Deposit amount is outside allowed range"});
  if(!["BKASH","NAGAD"].includes(method))return res.status(400).json({ok:false,message:"Unsupported payment method"});
  const db=getDb(),userRef=db.ref("users/"+phone),userSnap=await userRef.get();
  if(!userSnap.exists())return res.status(404).json({ok:false,message:"Account not found. Please log in again."});
  const user=userSnap.val()||{},memberName=String(user.memberName||"MEMBER").trim().slice(0,80);
  const appId=required("FZ_APP_ID"),secret=required("FZ_SECRET"),endpoint=process.env.FZ_API||"https://fzpay.site/api.php";
  const callbackUrl=required("FZ_CALLBACK_URL"),baseUrl=required("APP_BASE_URL").replace(/\/$/,"");
  if(new URL(endpoint).protocol!=="https:"||new URL(callbackUrl).protocol!=="https:")throw Error("HTTPS endpoint and callback required");
  orderNo="SL"+Date.now()+crypto.randomBytes(5).toString("hex").toUpperCase();
  const now=Date.now(),amount=Number((amountMinor/100).toFixed(2)),date=new Date(now).toLocaleString("en-GB",{timeZone:"Asia/Dhaka"});
  const saved={orderNo,phone,amount,method:method.toLowerCase(),status:"Pending",createdAt:now,timestamp:now,date,currency:"BDT",provider:"FZPay"};
  await db.ref("fzpayOrders/"+orderNo).set(saved);
  await db.ref("deposits/"+orderNo).set({phone,amount,method:method.toLowerCase(),status:"Pending",date,timestamp:now,provider:"FZPay",orderNo});
  const fields={app_id:appId,timestamp:String(Math.floor(Date.now()/1000)),action:"deposit",order_no:orderNo,amount:amount.toFixed(2),method,name:memberName,callback_url:callbackUrl,return_url:baseUrl+"/?deposit_return="+encodeURIComponent(orderNo)};
  fields.sign=sign(fields,secret);
  let upstream;
  try{upstream=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json","Accept":"application/json"},body:JSON.stringify(fields),redirect:"error",signal:AbortSignal.timeout(105000)});}
  catch(e){await db.ref("fzpayOrders/"+orderNo).update({gatewayRequest:"unknown",lastError:String(e.message||"network error")});return res.status(202).json({ok:false,uncertain:true,orderNo,message:"Gateway response is uncertain. Do not create another payment yet; contact support with this order number."});}
  let result;try{result=await upstream.json();}catch{await db.ref("fzpayOrders/"+orderNo).update({gatewayRequest:"unknown",lastError:"Non-JSON response"});return res.status(202).json({ok:false,uncertain:true,orderNo,message:"Gateway response is uncertain. Keep this order number and contact support."});}
  if(!upstream.ok||result.ok!==true||typeof result.payUrl!=="string"||!/^https:\/\//i.test(result.payUrl)){
   await db.ref("fzpayOrders/"+orderNo).update({gatewayRequest:"rejected",gatewayMessage:String(result.message||"Gateway rejected request")});
   await db.ref("deposits/"+orderNo).update({status:"Failed"});
   return res.status(502).json({ok:false,orderNo,message:result.message||"FZPay could not create the payment"});
  }
  await db.ref("fzpayOrders/"+orderNo).update({gatewayRequest:"accepted",gatewayStatus:String(result.status||"pending"),reference:String(result.reference||""),payUrl:result.payUrl});
  return res.status(200).json({ok:true,payUrl:result.payUrl,orderNo});
 }catch(e){console.error("FZPay create deposit:",e);return res.status(500).json({ok:false,orderNo:orderNo||undefined,message:"Server configuration or payment setup error. Please contact support."});}
};
