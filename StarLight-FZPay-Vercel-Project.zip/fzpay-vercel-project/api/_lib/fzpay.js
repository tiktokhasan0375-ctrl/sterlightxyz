const crypto = require("node:crypto");
const admin = require("firebase-admin");
function required(name) { const v=process.env[name]; if(!v) throw new Error(`Missing environment variable: ${name}`); return v; }
function getDb() {
  if (!admin.apps.length) {
    let serviceAccount;
    try { serviceAccount=JSON.parse(required("FIREBASE_SERVICE_ACCOUNT")); }
    catch { throw new Error("FIREBASE_SERVICE_ACCOUNT must contain the service-account JSON"); }
    admin.initializeApp({credential:admin.credential.cert(serviceAccount),databaseURL:required("FIREBASE_DATABASE_URL")});
  }
  return admin.database();
}
function enc(v){return encodeURIComponent(String(v)).replace(/[!'()*]/g,c=>"%"+c.charCodeAt(0).toString(16).toUpperCase());}
function sign(fields,secret){
  const canonical=Object.keys(fields).filter(k=>k!=="sign"&&fields[k]!==undefined&&fields[k]!==null).sort().map(k=>{
    let v=fields[k]; if(!["string","number","boolean"].includes(typeof v)) throw Error("Scalar fields required");
    if(typeof v==="boolean")v=v?"1":"0"; return enc(k)+"="+enc(v);
  }).join("&");
  return crypto.createHmac("sha256",secret).update(canonical,"utf8").digest("hex");
}
function verifySignature(fields,secret){
  const got=fields&&fields.sign;if(typeof got!=="string"||!/^[a-f0-9]{64}$/i.test(got))return false;
  const a=Buffer.from(got,"hex"),b=Buffer.from(sign(fields,secret),"hex");
  return a.length===b.length&&crypto.timingSafeEqual(a,b);
}
function minor(v){const s=String(v);if(!/^\d{1,10}(?:\.\d{1,2})?$/.test(s))throw Error("Invalid decimal amount");const p=s.split(".");return Number(p[0])*100+Number(((p[1]||"")+"00").slice(0,2));}
function major(v){return Number((v/100).toFixed(2));}
function jsonBody(req){if(req.body&&typeof req.body==="object")return req.body;if(typeof req.body==="string")return JSON.parse(req.body);return {};}
module.exports={getDb,required,sign,verifySignature,minor,major,jsonBody};
