const {getDb,required,verifySignature,minor,major,jsonBody}=require("./_lib/fzpay");
module.exports=async function(req,res){
 res.setHeader("Cache-Control","no-store");res.setHeader("Content-Type","text/plain; charset=utf-8");
 if(req.method!=="POST")return res.status(405).send("POST required");
 try{
  const a=jsonBody(req),appId=required("FZ_APP_ID"),secret=required("FZ_SECRET");
  if(!a||a.app_id!==appId||!verifySignature(a,secret))return res.status(403).send("invalid signature");
  const type=String(a.type||"").toLowerCase(),status=String(a.status||"").toLowerCase();
  if(type!=="deposit"||!["success","failed"].includes(status))return res.status(400).send("unsupported settlement");
  const orderNo=String(a.order_no||""),reference=String(a.reference||""),currency=String(a.currency||"").toUpperCase();
  if(!/^[A-Za-z0-9_-]{8,100}$/.test(orderNo)||!reference||currency!=="BDT")return res.status(400).send("invalid settlement fields");
  const gross=minor(a.amount),fee=minor(a.fee),net=minor(a.net_amount);
  if(gross<1||fee<0||net!==gross-fee)return res.status(400).send("invalid settlement amounts");
  const db=getDb(),orderRef=db.ref("fzpayOrders/"+orderNo),snap=await orderRef.get();
  if(!snap.exists())return res.status(404).send("unknown order");
  const order=snap.val()||{};
  if(order.provider!=="FZPay"||order.currency!==currency||minor(String(order.amount))!==gross)return res.status(409).send("order amount mismatch");
  if(order.reference&&order.reference!==reference)return res.status(409).send("reference mismatch");
  const finalStatus=status==="success"?"Success":"Failed";
  const now=Date.now(),patch={status:finalStatus,reference,fee:major(fee),netAmount:major(net),utr:String(a.utr||""),settledAt:now,callbackEventId:String(a.event_id||"")};
  // Lock terminal status first so conflicting final callbacks cannot race.
  const orderTx=await orderRef.transaction(current=>{
   if(!current)return;
   if(current.status==="Pending"){Object.assign(current,patch);return current;}
   if(current.status===finalStatus)return current;
   return;
  },undefined,false);
  if(!orderTx.committed)return res.status(409).send("conflicting final status");
  if(status==="success"){
   const phone=String(order.phone||"");if(!/^[0-9]{6,20}$/.test(phone))return res.status(409).send("invalid saved customer");
   const userRef=db.ref("users/"+phone),userSnap=await userRef.get();if(!userSnap.exists())return res.status(404).send("customer not found");
   const policy=(process.env.FZ_DEPOSIT_CREDIT_POLICY||"net").toLowerCase();if(!["net","gross"].includes(policy))return res.status(500).send("invalid credit policy");
   const creditMinor=policy==="gross"?gross:net,receiptKey=orderNo.replace(/[.#$\/\[\]]/g,"_");
   const tx=await userRef.transaction(current=>{
    if(!current)return;
    const receipts=current.depositReceipts&&typeof current.depositReceipts==="object"?current.depositReceipts:{};
    if(receipts[receiptKey])return current;
    current.balance=Number((Number(current.balance||0)+major(creditMinor)).toFixed(2));
    current.depositReceipts={...receipts,[receiptKey]:true};return current;
   },undefined,false);
   if(!tx.committed)return res.status(503).send("wallet transaction not committed");
  }
  await db.ref("deposits/"+orderNo).update(patch);
  return res.status(200).send("ok");
 }catch(e){console.error("FZPay callback settlement error:",e);return res.status(503).send("retry");}
};
